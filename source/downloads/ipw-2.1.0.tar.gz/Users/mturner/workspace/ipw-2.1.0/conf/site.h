/*  This is the site-specific header file.  Place only those C preprocessor
 *  directives that are specific to this local site in this file.  Those
 *  directives that are specific to a particular host OS should be placed
 *  in a separate file in the directory "hosts".
 */
